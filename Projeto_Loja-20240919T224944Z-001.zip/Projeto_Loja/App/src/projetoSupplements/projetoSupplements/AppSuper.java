package projetoSupplements;
import java.util.Scanner;

public class AppSuper {


   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         Prateleiras prateleiras = new Prateleiras();
        prateleiras.listtodosHiper();
         

   }
    
}
