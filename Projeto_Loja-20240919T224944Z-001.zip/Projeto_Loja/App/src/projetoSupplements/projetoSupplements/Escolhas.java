package projetoSupplements;
import java.util.Scanner;
public class Escolhas {
    
}
